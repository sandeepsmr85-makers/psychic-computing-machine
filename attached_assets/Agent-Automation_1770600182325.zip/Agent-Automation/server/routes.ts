
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { UniversalWebAutomation } from "./automation/system";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // === Automation Runs ===

  app.get(api.runs.list.path, async (req, res) => {
    const runs = await storage.listRuns();
    res.json(runs);
  });

  app.get(api.runs.get.path, async (req, res) => {
    const run = await storage.getRun(Number(req.params.id));
    if (!run) {
      return res.status(404).json({ message: "Run not found" });
    }
    res.json(run);
  });

  app.post(api.runs.create.path, async (req, res) => {
    try {
      const input = api.runs.create.input.parse(req.body);
      
      // Create the run record
      const run = await storage.createRun({
        url: input.url,
        instruction: input.instruction,
        status: "running",
      });

      // Start automation in background
      // Note: In a real production app, use a job queue (Bull/Redis).
      // Here we just fire and forget, logging to DB.
      (async () => {
        const automation = new UniversalWebAutomation(run.id);
        try {
          await automation.initialize({ 
            env: process.env.BROWSERBASE_API_KEY ? "BROWSERBASE" : "LOCAL",
            headless: true 
          });

          if (input.url) {
            await automation.goto(input.url);
          } else {
             // If no URL, maybe it's in the instruction or we are already somewhere?
             // For now require URL or handle gracefully
          }

          const result = await automation.prompt(input.instruction);
          
          await storage.updateRun(run.id, {
            status: "completed",
            result: result,
            endTime: new Date(),
            cost: Math.round(result.cost * 100)
          });
          
        } catch (error) {
          console.error(`Run ${run.id} failed:`, error);
          await storage.updateRun(run.id, {
            status: "failed",
            result: { error: String(error) },
            endTime: new Date()
          });
          await storage.appendRunLog(run.id, `❌ Fatal Error: ${String(error)}`);
        } finally {
            try {
                await automation.close();
            } catch (e) {
                // ignore
            }
        }
      })();

      res.status(201).json(run);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // === Cached Actions ===

  app.get(api.actions.list.path, async (req, res) => {
    const website = req.query.website as string | undefined;
    const actions = await storage.listCachedActions(website);
    res.json(actions);
  });

  app.delete(api.actions.delete.path, async (req, res) => {
    await storage.deleteCachedAction(Number(req.params.id));
    res.status(204).send();
  });

  return httpServer;
}
